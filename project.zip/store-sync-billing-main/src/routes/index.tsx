import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "محاسب فارس — تطبيق محاسبي" },
      { name: "description", content: "محاسب فارس: تطبيق محاسبي يعمل بدون إنترنت للمبيعات والمشتريات والمخزون." },
      { property: "og:title", content: "محاسب فارس — تطبيق محاسبي" },
      { property: "og:description", content: "تطبيق محاسبي يعمل بدون إنترنت للمبيعات والمشتريات والمخزون." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

function Index() {
  return <iframe src="/faris/index.html" title="محاسب فارس" style={{ position: "fixed", inset: 0, width: "100%", height: "100%", border: 0 }} />;
}
