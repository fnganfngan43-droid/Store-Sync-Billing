/* =========================================================
   وحدات القياس
   ========================================================= */

const InvUnits = (function () {
  let selectedId = null;

  async function render(container) {
    selectedId = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="iu-add">➕ إضافة</button>
        <button class="btn btn-icon" id="iu-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="iu-del" disabled>🗑️ حذف</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>الرمز</th><th>الاسم</th><th>العبوة الافتراضية</th><th>النوع</th></tr></thead>
          <tbody id="iu-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet" id="iu-sheet">
        <div class="sheet-handle"></div>
        <h3>بيانات وحدة القياس</h3>
        <form id="iu-form">
          <div class="form-grid">
            <label class="required">رمز الوحدة<input type="text" id="iu-code" required></label>
            <label class="required">اسم الوحدة<input type="text" id="iu-name" required></label>
            <label class="optional">العبوة الافتراضية<input type="text" id="iu-package"></label>
            <label class="required">نوع الوحدة
              <select id="iu-type"><option value="عددية">عددية</option><option value="قياسية">قياسية</option></select>
            </label>
          </div>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="iu-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>
    `;

    container.querySelector('#iu-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#iu-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#iu-del').addEventListener('click', onDelete);
    container.querySelector('#iu-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('iu-sheet')));
    container.querySelector('#iu-form').addEventListener('submit', onSave);

    await loadRows();
  }

  async function loadRows() {
    const items = await FarisDB.getAll(STORES.INV_UNITS);
    const rows = document.getElementById('iu-rows');
    rows.innerHTML = items.map(u => `
      <tr data-id="${u.id}">
        <td>${Utils.escapeHtml(u.code)}</td><td>${Utils.escapeHtml(u.name)}</td>
        <td>${Utils.escapeHtml(u.package || '')}</td><td>${Utils.escapeHtml(u.type)}</td>
      </tr>`).join('') || '<tr><td colspan="4" class="empty-row">لا توجد وحدات قياس بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#iu-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('iu-edit').disabled = false;
    document.getElementById('iu-del').disabled = false;
  }

  async function openSheet(id) {
    const sheet = document.getElementById('iu-sheet');
    document.getElementById('iu-form').reset();
    if (id) {
      const u = await FarisDB.get(STORES.INV_UNITS, id);
      document.getElementById('iu-code').value = u.code;
      document.getElementById('iu-name').value = u.name;
      document.getElementById('iu-package').value = u.package || '';
      document.getElementById('iu-type').value = u.type;
      sheet.dataset.editId = id;
    } else {
      sheet.dataset.editId = '';
    }
    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('iu-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;
    const value = {
      code: document.getElementById('iu-code').value.trim(),
      name: document.getElementById('iu-name').value.trim(),
      package: document.getElementById('iu-package').value.trim(),
      type: document.getElementById('iu-type').value
    };
    if (editId) value.id = editId;

    const existing = await FarisDB.getAll(STORES.INV_UNITS);
    if (existing.some(u => (u.code === value.code || u.name === value.name) && u.id !== editId)) {
      Utils.toast('رمز أو اسم الوحدة مستخدم مسبقًا', 'error');
      return;
    }

    await FarisDB.put(STORES.INV_UNITS, value);
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف وحدة القياس هذه؟');
    if (!ok) return;
    await FarisDB.remove(STORES.INV_UNITS, selectedId);
    selectedId = null;
    document.getElementById('iu-edit').disabled = true;
    document.getElementById('iu-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  return { render };
})();
