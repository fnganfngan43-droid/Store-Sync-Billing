/* =========================================================
   شاشة المخزون - الحاوية وشريط التنقل بين شاشاتها الفرعية
   ========================================================= */

const ScreenInventory = (function () {
  const tabs = [
    { key: 'config', label: 'تهيئة المخزن', icon: '⚙️', render: (c) => InvConfig.render(c) },
    { key: 'units', label: 'وحدات القياس', icon: '📏', render: (c) => InvUnits.render(c) },
    { key: 'groups', label: 'المجموعات', icon: '🗂️', render: (c) => InvGroups.render(c) },
    { key: 'warehouses', label: 'بيانات المخزون', icon: '🏬', render: (c) => InvWarehouses.render(c) },
    { key: 'glMapping', label: 'ربط المخزون بالأستاذ العام', icon: '🔗', render: (c) => InvGlMapping.render(c) },
    { key: 'items', label: 'بيانات الأصناف', icon: '📦', render: (c) => InvItems.render(c) },
    { key: 'itemCard', label: 'بطاقة حركة الصنف', icon: '📇', render: (c, params) => InvItemCard.render(c, params) },
    { key: 'opening', label: 'المخزون الافتتاحي', icon: '🏁', render: (c) => InvOpeningStock.render(c) },
    { key: 'pricingLevels', label: 'مستويات التسعير', icon: '🏷️', render: (c) => InvStub.render(c, 'pricingLevels') },
    { key: 'itemPricing', label: 'تسعير الأصناف', icon: '💲', render: (c) => InvStub.render(c, 'itemPricing') },
    { key: 'stockCount', label: 'الجرد', icon: '📋', render: (c) => InvStub.render(c, 'stockCount') },
    { key: 'closing', label: 'إقفال المخزون', icon: '🔒', render: (c) => InvStub.render(c, 'closing') }
  ];

  let activeTab = null;
  let tabBeforeItemCard = null;

  function init() {
    App.register('inventory', { onShow });

    document.getElementById('inventory-back-home').addEventListener('click', () => App.show('home', { replace: true }));
    document.getElementById('inventory-open-config').addEventListener('click', () => selectTab('config'));

    const nav = document.getElementById('inventory-nav');
    nav.innerHTML = tabs.filter(t => t.key !== 'config').map(t => `
      <button class="nav-icon-btn" data-key="${t.key}">
        <span class="nav-icon">${t.icon}</span>
        <span class="nav-label">${t.label}</span>
      </button>`).join('');

    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      selectTab(btn.dataset.key);
    });
  }

  function onShow() {
    selectTab(activeTab || 'config');
  }

  function selectTab(key, params) {
    activeTab = key;
    document.querySelectorAll('#inventory-nav .nav-icon-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.key === key);
    });
    const tab = tabs.find(t => t.key === key);
    const content = document.getElementById('inventory-content');
    content.innerHTML = '';
    tab.render(content, params);
  }

  // يُستدعى من شاشة بيانات الأصناف لفتح بطاقة حركة صنف محدد مباشرة
  function openItemCard(params) {
    tabBeforeItemCard = activeTab;
    selectTab('itemCard', params);
  }

  function backFromItemCard() {
    selectTab(tabBeforeItemCard || 'items');
  }

  return { init, openItemCard, backFromItemCard };
})();
