/* تقرير المخزون: أرصدة/حركة مع التصفية والطباعة وتصدير Excel */
const ReportInventoryStub = (function () {
  const TITLES = { stock: 'تقرير المخزون', stockMove: 'تقرير حركة المخزون' };
  const esc = (v) => Utils.escapeHtml(String(v ?? ''));
  const dateToday = () => new Date().toISOString().slice(0, 10);

  async function render(container, key) {
    const isMove = key === 'stockMove';
    const [items, mains, warehouses] = await Promise.all([
      FarisDB.getAll(STORES.INV_ITEMS),
      FarisDB.getAll(STORES.INV_GROUPS_MAIN),
      FarisDB.getAll(STORES.INV_WAREHOUSES)
    ]);
    const mainMap = Object.fromEntries(mains.map(x => [String(x.id), x.name]));
    container.innerHTML = `
      <h3 style="margin:0 0 10px">${TITLES[key]}</h3>
      <div class="toolbar">
        <button class="btn btn-primary" id="ir-show">🔍 عرض</button>
        <button class="btn btn-ghost" id="ir-print">🖨️ طباعة</button>
        <button class="btn btn-ghost" id="ir-excel">📊 تصدير إكسل</button>
      </div>
      <div class="form-grid" style="margin-bottom:12px">
        <label>من تاريخ<input type="date" id="ir-date-from"></label>
        <label>إلى تاريخ<input type="date" id="ir-date-to" value="${dateToday()}"></label>
        <label>من رقم/اسم صنف<input id="ir-item-from" list="ir-items-list" placeholder="بحث بالرقم أو الاسم"></label>
        <label>إلى رقم/اسم صنف<input id="ir-item-to" list="ir-items-list" placeholder="بحث بالرقم أو الاسم"></label>
        <datalist id="ir-items-list">${items.map(i=>`<option value="${esc(i.code)}">${esc(i.name)}</option><option value="${esc(i.name)}"></option>`).join('')}</datalist>
        <label>من مجموعة رئيسية<select id="ir-group-from"><option value="">الكل</option>${mains.map(g=>`<option value="${esc(g.id)}">${esc(g.name)}</option>`).join('')}</select></label>
        <label>إلى مجموعة رئيسية<select id="ir-group-to"><option value="">الكل</option>${mains.map(g=>`<option value="${esc(g.id)}">${esc(g.name)}</option>`).join('')}</select></label>
        <label>من مخزون<select id="ir-wh-from"><option value="">الكل</option>${warehouses.map(w=>`<option value="${esc(w.id)}">${esc(w.name)}</option>`).join('')}</select></label>
        <label>إلى مخزون<select id="ir-wh-to"><option value="">الكل</option>${warehouses.map(w=>`<option value="${esc(w.id)}">${esc(w.name)}</option>`).join('')}</select></label>
        <label>تصفية الكمية<select id="ir-qty-op"><option value="">بدون تصفية</option><option value="gt">أكبر من</option><option value="lt">أصغر من</option><option value="eq">يساوي</option></select></label>
        <label>الكمية<input type="number" step="any" id="ir-qty" placeholder="أدخل الكمية"></label>
        <label>نوع التقرير<select id="ir-type"><option value="qty">كميات</option><option value="cost">كميات وتكاليف</option></select></label>
        <label>فرز حسب<select id="ir-sort"><option value="all">كلي</option><option value="qty">الكميات</option><option value="name">الاسم</option><option value="code">الرقم</option><option value="group">المجموعة</option></select></label>
      </div>
      <div class="table-scroll" id="ir-results"><p class="empty-row">اضغط «عرض» لإظهار التقرير.</p></div>
    `;
    const $ = id => container.querySelector('#'+id);
    $('ir-show').addEventListener('click', async () => {
      const rows = await buildRows({items, mains, warehouses, mainMap, isMove, filters: {
        fromDate:$('ir-date-from').value, toDate:$('ir-date-to').value,
        itemFrom:$('ir-item-from').value.trim(), itemTo:$('ir-item-to').value.trim(),
        groupFrom:$('ir-group-from').value, groupTo:$('ir-group-to').value,
        whFrom:$('ir-wh-from').value, whTo:$('ir-wh-to').value,
        op:$('ir-qty-op').value, qty:$('ir-qty').value, type:$('ir-type').value, sort:$('ir-sort').value
      }});
      renderRows($('ir-results'), rows, $('ir-type').value, isMove);
      $('ir-results').dataset.rows = JSON.stringify(rows);
      $('ir-results').dataset.type = $('ir-type').value;
      $('ir-results').dataset.move = String(isMove);
    });
    $('ir-print').addEventListener('click', async () => {
      const table = $('ir-results').querySelector('table');
      if (!table) return Utils.toast('اعرض التقرير أولاً', 'error');
      const settings = await FarisDB.get(STORES.SETTINGS, 'main').catch(() => null) || {};
      const arLines = [settings.arLine1, settings.arLine2, settings.arLine3].filter(Boolean);
      const enLines = [settings.enLine1, settings.enLine2, settings.enLine3].filter(Boolean);
      const logo = settings.logo ? `<img class="logo" src="${settings.logo}" alt="شعار المنشأة">` : '';
      const html = `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${TITLES[key]}</title><style>@page{margin:12mm}body{font-family:Arial;padding:18px}h2{text-align:center}.letterhead{border:1px solid #333;border-radius:8px;padding:10px;margin-bottom:12px}.head{display:grid;grid-template-columns:1fr 60px 1fr;align-items:center;gap:8px;font-weight:bold;font-size:11px}.head>div:first-child{text-align:right}.head>div:last-child{text-align:left}.logo{width:54px;height:54px;border-radius:50%;object-fit:cover;border:1px solid #777}table{width:100%;border-collapse:collapse}th,td{border:1px solid #333;padding:6px;text-align:right}th{background:#eee}</style></head><body><header class="letterhead"><div class="head"><div>${arLines.map(x=>`<div>${Utils.escapeHtml(x)}</div>`).join('')}</div><div>${logo}</div><div dir="ltr">${enLines.map(x=>`<div>${Utils.escapeHtml(x)}</div>`).join('')}</div></div><h2>${TITLES[key]}</h2></header>${table.outerHTML}</body></html>`;
      await Utils.printHtml(TITLES[key], html);
    });
    $('ir-excel').addEventListener('click', () => {
      const table = $('ir-results').querySelector('table');
      if (!table) return Utils.toast('اعرض التقرير أولاً', 'error');
      if (typeof XLSX === 'undefined') return Utils.toast('مكتبة إكسل غير متاحة', 'error');
      const wb = XLSX.utils.table_to_book(table, {sheet: 'تقرير المخزون'});
      XLSX.writeFile(wb, `${isMove ? 'تقرير-حركة-المخزون' : 'تقرير-المخزون'}.xlsx`);
    });
  }

  function resolveItem(value, items) {
    if (!value) return null;
    const v = String(value).trim().toLowerCase();
    return items.find(i => String(i.code ?? '').toLowerCase() === v || String(i.name ?? '').toLowerCase() === v)
      || items.find(i => String(i.code ?? '').toLowerCase().includes(v) || String(i.name ?? '').toLowerCase().includes(v));
  }

  async function buildRows({items, mains, warehouses, mainMap, isMove, filters:f}) {
    items = [...items].sort((a,b)=>String(a.code||'').localeCompare(String(b.code||''),'ar',{numeric:true}));
    const fromItem = resolveItem(f.itemFrom, items), toItem = resolveItem(f.itemTo, items);
    const itemFromCode = fromItem ? String(fromItem.code) : '';
    const itemToCode = toItem ? String(toItem.code) : '';
    const fromIndex = itemFromCode ? items.findIndex(i=>String(i.code)===itemFromCode) : 0;
    const toIndex = itemToCode ? items.findIndex(i=>String(i.code)===itemToCode) : items.length-1;
    const low = Math.min(fromIndex, toIndex), high = Math.max(fromIndex, toIndex);
    const whFrom = f.whFrom ? warehouses.findIndex(w=>String(w.id)===f.whFrom) : 0;
    const whTo = f.whTo ? warehouses.findIndex(w=>String(w.id)===f.whTo) : warehouses.length-1;
    const whLow=Math.min(whFrom,whTo), whHigh=Math.max(whFrom,whTo);
    const groupFrom = f.groupFrom ? mains.findIndex(g=>String(g.id)===f.groupFrom) : 0;
    const groupTo = f.groupTo ? mains.findIndex(g=>String(g.id)===f.groupTo) : mains.length-1;
    const groupLow=Math.min(groupFrom,groupTo), groupHigh=Math.max(groupFrom,groupTo);
    const result=[];
    for (let ix=0; ix<items.length; ix++) {
      const item=items[ix];
      if ((f.itemFrom || f.itemTo) && (ix<low || ix>high)) continue;
      const mainId = item.mainGroupId ?? item.groupId ?? item.mainGroup;
      const gi=mains.findIndex(g=>String(g.id)===String(mainId));
      if ((f.groupFrom || f.groupTo) && (gi<groupLow || gi>groupHigh)) continue;
      const movements=await ItemMovementEngine.gatherRawMovements(item.code);
      const byWarehouse=new Map();
      movements.forEach(m=>{
        if (f.fromDate && m.date && m.date < f.fromDate) return;
        if (f.toDate && m.date && m.date > f.toDate) return;
        const id=String(m.warehouseId ?? '');
        const entry=byWarehouse.get(id)||{qty:0,cost:0};
        const incoming=Number(m.incomingBaseQty)||0, outgoing=Number(m.outgoingBaseQty)||0;
        entry.qty += incoming-outgoing;
        const unitCost=Number(m.unitCost)||0;
        entry.cost += (incoming-outgoing)*unitCost;
        byWarehouse.set(id,entry);
      });
      const selectedWarehouses=warehouses.filter((w,wi)=>wi>=whLow && wi<=whHigh && ((f.whFrom||f.whTo) ? true : true));
      for (const w of selectedWarehouses) {
        const b=byWarehouse.get(String(w.id))||{qty:0,cost:0};
        const qty=Math.round(b.qty*1000)/1000, cost=Math.round(b.cost*100)/100;
        if (f.op && f.qty !== '') {
          const n=Number(f.qty);
          if (f.op==='gt' && !(qty>n) || f.op==='lt' && !(qty<n) || f.op==='eq' && !(qty===n)) continue;
        }
        if (!isMove && qty===0 && cost===0) continue;
        result.push({code:item.code||'',name:item.name||'',group:mainMap[String(mainId)]||'',warehouse:w.name||'',qty,cost});
      }
    }
    const sort=f.sort;
    if (sort==='qty') result.sort((a,b)=>b.qty-a.qty);
    else if (sort==='name') result.sort((a,b)=>String(a.name).localeCompare(String(b.name),'ar'));
    else if (sort==='code') result.sort((a,b)=>String(a.code).localeCompare(String(b.code),'ar',{numeric:true}));
    else if (sort==='group') result.sort((a,b)=>String(a.group).localeCompare(String(b.group),'ar'));
    else result.sort((a,b)=>String(a.code).localeCompare(String(b.code),'ar',{numeric:true}));
    return result;
  }

  function renderRows(el, rows, type, isMove) {
    const costCols=type==='cost' ? '<th>التكلفة</th>' : '';
    const body=rows.length ? rows.map(r=>`<tr><td>${esc(r.code)}</td><td>${esc(r.name)}</td><td>${esc(r.group)}</td><td>${esc(r.warehouse)}</td><td>${r.qty}</td>${type==='cost'?`<td>${r.cost.toFixed(2)}</td>`:''}</tr>`).join('') :
      `<tr><td colspan="${type==='cost'?6:5}" class="empty-row">لا توجد بيانات مطابقة للتصفية</td></tr>`;
    const totalQty=rows.reduce((s,r)=>s+r.qty,0), totalCost=rows.reduce((s,r)=>s+r.cost,0);
    el.innerHTML=`<div class="table-scroll"><table class="data-table"><thead><tr><th>رقم الصنف</th><th>اسم الصنف</th><th>المجموعة الرئيسية</th><th>المخزون</th><th>${isMove?'صافي الكمية':'الكمية'}</th>${costCols}</tr></thead><tbody>${body}<tr><td colspan="4"><b>الإجمالي</b></td><td><b>${Math.round(totalQty*1000)/1000}</b></td>${type==='cost'?`<td><b>${totalCost.toFixed(2)}</b></td>`:''}</tr></tbody></table></div>`;
  }
  return { render };
})();