/* =========================================================
   طبقة تجميع بيانات التقارير (قراءة فقط من IndexedDB)
   ========================================================= */

const ReportData = (function () {

  const OP_NAMES = {
    opening: 'الأرصدة الافتتاحية',
    journal: 'القيود اليومية',
    receipt: 'سند قبض',
    payment: 'سند الصرف',
    exchange: 'صرف عملة'
  };

  // يستخرج "هوية" الحساب التحليلي (رقم الطرف بلا بادئة رقم الحساب الفرعي) لمقارنة مرنة
  // تتحمل اختلافات صيغة التخزين القديمة (مثال: "11001-3" أو "3" أو حتى بادئات أخرى)
  function analyticIdentity(accountCode, analyticCode) {
    if (!analyticCode) return '';
    if (analyticCode === accountCode) return ''; // نوع عام: لا هوية تحليلية منفصلة
    if (accountCode && analyticCode.startsWith(`${accountCode}-`)) {
      return analyticCode.slice(accountCode.length + 1);
    }
    const dash = analyticCode.lastIndexOf('-');
    return dash >= 0 ? analyticCode.slice(dash + 1) : analyticCode;
  }

  // يجمع كل الحركات المرتبطة بحساب فرعي معيّن (وحساب تحليلي محدد اختياريًا) ضمن فترة
  async function getLedgerTransactions({ accountCode, analyticCode, fromDate, toDate, currencyId, opFilter }) {
    if (!accountCode) return [];
    const tx = [];

    const wantedIdentity = analyticCode !== undefined && analyticCode !== null ? analyticIdentity(accountCode, analyticCode) : null;
    const inRange = (d) => (!fromDate || d >= fromDate) && (!toDate || d <= toDate);
    // إن لم يُطلب تصفية بحساب تحليلي محدد (analyticCode فارغ/غير معطى) لا نصفّي بحسبه إطلاقًا؛
    // وإلا نقارن الهوية المستخرجة من كود المعاملة نفسه (مرنة، بلا اشتراط تطابق حرفي كامل)
    const matchesAnalytic = (txAccountCode, txAnalyticCode) => {
      if (analyticCode === undefined || analyticCode === null || analyticCode === '') return true;
      return analyticIdentity(txAccountCode, txAnalyticCode) === wantedIdentity;
    };
    const matchesCurrency = (id) => !currencyId || id === currencyId;
    const allowOp = (key) => !opFilter || opFilter === 'كلي' || opFilter === key;

    if (allowOp('opening')) {
      const items = await FarisDB.getAllByIndex(STORES.OPENING_BALANCES, 'accountCode', accountCode);
      items.forEach(it => {
        if (!inRange(it.date) || !matchesAnalytic(it.accountCode, it.analyticCode) || !matchesCurrency(it.currencyId)) return;
        tx.push({ date: it.date, docType: OP_NAMES.opening, docNo: it.voucherNo, statement: it.statement, refNo: '', debit: it.debit || 0, credit: it.credit || 0, currencyId: it.currencyId, localDebit: it.localDebit, localCredit: it.localCredit });
      });
    }

    if (allowOp('journal')) {
      const entries = await FarisDB.getAll(STORES.JOURNAL);
      entries.forEach(entry => {
        if (!inRange(entry.date)) return;
        (entry.lines || []).forEach(l => {
          if (l.accountCode !== accountCode || !matchesAnalytic(l.accountCode, l.analyticCode) || !matchesCurrency(l.currencyId)) return;
          tx.push({ date: entry.date, docType: OP_NAMES.journal, docNo: entry.entryNo, statement: l.statement, refNo: l.refNo || '', debit: l.debit || 0, credit: l.credit || 0, currencyId: l.currencyId, localDebit: l.localDebit, localCredit: l.localCredit });
        });
      });
    }

    if (allowOp('receipt') || allowOp('payment')) {
      const vouchers = await FarisDB.getAll(STORES.VOUCHERS);
      vouchers.forEach(v => {
        if (!inRange(v.date)) return;
        if (!allowOp(v.type)) return;
        if (v.debitSide.accountCode === accountCode && matchesAnalytic(v.debitSide.accountCode, v.debitSide.analyticCode) && matchesCurrency(v.debitSide.currencyId)) {
          tx.push({ date: v.date, docType: OP_NAMES[v.type], docNo: v.voucherNo, statement: v.debitSide.statement, refNo: v.debitSide.refNo || '', debit: v.debitSide.amount || 0, credit: 0, currencyId: v.debitSide.currencyId, localDebit: v.debitSide.localDebit, localCredit: 0 });
        }
        if (v.creditSide.accountCode === accountCode && matchesAnalytic(v.creditSide.accountCode, v.creditSide.analyticCode) && matchesCurrency(v.creditSide.currencyId)) {
          tx.push({ date: v.date, docType: OP_NAMES[v.type], docNo: v.voucherNo, statement: v.creditSide.statement, refNo: v.creditSide.refNo || '', debit: 0, credit: v.creditSide.amount || 0, currencyId: v.creditSide.currencyId, localDebit: 0, localCredit: v.creditSide.localCredit });
        }
      });
    }

    if (allowOp('exchange')) {
      const exchanges = await FarisDB.getAll(STORES.CURRENCY_EXCHANGES);
      exchanges.forEach(ex => {
        if (!inRange(ex.date) || ex.accountCode !== accountCode || !matchesAnalytic(ex.accountCode, ex.analyticCode)) return;
        if (matchesCurrency(ex.fromCurrencyId)) {
          tx.push({ date: ex.date, docType: OP_NAMES.exchange, docNo: ex.no, statement: ex.fromStatement, refNo: ex.refNo || '', debit: 0, credit: ex.fromAmount || 0, currencyId: ex.fromCurrencyId, localDebit: 0, localCredit: ex.localCredit });
        }
        if (matchesCurrency(ex.toCurrencyId)) {
          tx.push({ date: ex.date, docType: OP_NAMES.exchange, docNo: ex.no, statement: ex.toStatement, refNo: ex.refNo || '', debit: ex.toAmount || 0, credit: 0, currencyId: ex.toCurrencyId, localDebit: ex.localDebit, localCredit: 0 });
        }
      });
    }

    tx.sort((a, b) => a.date.localeCompare(b.date));
    let balance = 0;
    tx.forEach(t => { balance += (t.debit - t.credit); t.balance = balance; });
    return tx;
  }

  // إجمالي مدين/دائن/رصيد لحساب معيّن (لكل مصادر الحركة) ضمن فترة، مع إمكانية التصفية بعملة معيّنة
  async function getAccountTotals(accountCode, analyticCode, fromDate, toDate, currencyId) {
    const tx = await getLedgerTransactions({ accountCode, analyticCode, fromDate, toDate, currencyId });
    const debit = tx.reduce((s, t) => s + t.debit, 0);
    const credit = tx.reduce((s, t) => s + t.credit, 0);
    return { debit, credit, balance: debit - credit, count: tx.length };
  }

  // نفس getAccountTotals لكن بعد تحويل كل حركة لعملتها المحلية (بصرف النظر عن عملة تسجيلها الأصلية)،
  // فيصلح لتجميع أرصدة حسابات تحتوي حركات بعملات متعددة في رقم موحّد بالعملة المحلية
  async function getAccountTotalsLocal(accountCode, analyticCode, fromDate, toDate, currenciesCache, currencyId) {
    const tx = await getLedgerTransactions({ accountCode, analyticCode, fromDate, toDate, currencyId });
    const currencies = currenciesCache || await FarisDB.getAll(STORES.CURRENCIES);
    const local = currencies.find(c => c.type === 'محلي');
    const toLocalAmount = (amount, currencyId) => {
      if (!amount) return 0;
      const cur = currencies.find(c => c.id === currencyId) || local;
      if (!cur || !local || cur.id === local.id) return amount;
      return cur.type === 'محلي' ? amount : amount * cur.rate;
    };
    // نستخدم عمود المبلغ بالعملة المحلية المخزّن، وللسجلات القديمة نحسبه بسعر الصرف الحالي
    const pick = (stored, amount, cid) => (typeof stored === 'number' && !isNaN(stored)) ? stored : toLocalAmount(amount, cid);
    const debit = tx.reduce((s, t) => s + pick(t.localDebit, t.debit, t.currencyId), 0);
    const credit = tx.reduce((s, t) => s + pick(t.localCredit, t.credit, t.currencyId), 0);
    return { debit, credit, balance: debit - credit, count: tx.length };
  }

  // قائمة كل الحسابات الفرعية (تُستخدم كأساس لميزان المراجعة وتقرير الدليل)
  async function getAllSubAccountsFlat() {
    const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
    return accounts.filter(a => a.type === 'فرعي').sort((a, b) => a.code.localeCompare(b.code));
  }

  async function getAllAccountsFlat() {
    const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
    return accounts.sort((a, b) => a.code.localeCompare(b.code));
  }

  // يتحقق هل لهذا الحساب/الحساب التحليلي أي حركة فعلية في شاشة العمليات (لمنع الحذف)
  async function hasMovement(accountCode, analyticCode) {
    const wantedIdentity = analyticCode ? analyticIdentity(accountCode, analyticCode) : null;
    const matches = (txAccountCode, txAnalyticCode) => !wantedIdentity || analyticIdentity(txAccountCode, txAnalyticCode) === wantedIdentity;

    const obs = await FarisDB.getAllByIndex(STORES.OPENING_BALANCES, 'accountCode', accountCode);
    if (obs.some(o => matches(o.accountCode, o.analyticCode))) return true;

    const entries = await FarisDB.getAll(STORES.JOURNAL);
    for (const entry of entries) {
      if ((entry.lines || []).some(l => l.accountCode === accountCode && matches(l.accountCode, l.analyticCode))) return true;
    }

    const vouchers = await FarisDB.getAll(STORES.VOUCHERS);
    for (const v of vouchers) {
      if (v.debitSide.accountCode === accountCode && matches(v.debitSide.accountCode, v.debitSide.analyticCode)) return true;
      if (v.creditSide.accountCode === accountCode && matches(v.creditSide.accountCode, v.creditSide.analyticCode)) return true;
    }

    const exchanges = await FarisDB.getAll(STORES.CURRENCY_EXCHANGES);
    if (exchanges.some(ex => ex.accountCode === accountCode && matches(ex.accountCode, ex.analyticCode))) return true;

    return false;
  }

  return { getLedgerTransactions, getAccountTotals, getAccountTotalsLocal, getAllSubAccountsFlat, getAllAccountsFlat, hasMovement, OP_NAMES };
})();
