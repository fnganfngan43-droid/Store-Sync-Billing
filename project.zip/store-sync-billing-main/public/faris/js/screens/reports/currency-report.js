/* =========================================================
   تقرير العملات
   ========================================================= */

const ReportCurrencyReport = (function () {
  let lastResult = null;

  async function render(container) {
    lastResult = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-primary" id="cr-view">🔍 عرض</button>
        ${ReportPrint.toolbarHtml('cr')}
      </div>
      <div id="cr-result"></div>
    `;
    container.querySelector('#cr-view').addEventListener('click', onView);
    ReportPrint.bindToolbar('cr', async () => lastResult);
    onView();
  }

  async function onView() {
    const currencies = await FarisDB.getAll(STORES.CURRENCIES);
    const headers = ['اسم العملة', 'الرمز', 'النوع', 'الفكة', 'سعر الصرف', 'الحد الأدنى', 'الحد الأقصى'];
    const rows = currencies.map(c => [
      c.name, c.symbol, c.type || 'اجنبي', c.fraction || '', c.rate,
      c.type === 'اجنبي' ? (c.minRate ?? '') : '—',
      c.type === 'اجنبي' ? (c.maxRate ?? '') : '—'
    ]);
    lastResult = { title: 'تقرير العملات', headers, rows };

    document.getElementById('cr-result').innerHTML = `
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="7" class="empty-row">لا توجد عملات</td></tr>`}</tbody>
        </table>
      </div>
    `;
  }

  return { render };
})();
