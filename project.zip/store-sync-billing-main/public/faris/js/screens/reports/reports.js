/* =========================================================
   شاشة التقارير - الحاوية وشريط التنقل بين أنواع التقارير
   ========================================================= */

const ScreenReports = (function () {
  const SETTINGS_ID = 'main';

  const tabs = [
    { key: 'statement', label: 'كشف حساب', icon: '📄', render: (c) => ReportAccountStatement.render(c) },
    { key: 'trial', label: 'ميزان المراجعة', icon: '⚖️', render: (c) => ReportTrialBalance.render(c) },
    { key: 'income', label: 'قائمة الدخل', icon: '📈', render: (c) => ReportIncomeBalance.render(c, 'income') },
    { key: 'balance', label: 'الميزانية العمومية', icon: '🏛️', render: (c) => ReportIncomeBalance.render(c, 'balance') },
    { key: 'stock', label: 'رصيد المخزون', icon: '📦', render: (c) => ReportInventoryStub.render(c, 'stock') },
    { key: 'stockMove', label: 'حركة المخزون', icon: '🔁', render: (c) => ReportInventoryStub.render(c, 'stockMove') },
    { key: 'currencies', label: 'تقرير العملات', icon: '💱', render: (c) => ReportCurrencyReport.render(c) },
    { key: 'chart', label: 'تقرير الدليل', icon: '📒', render: (c) => ReportChartReport.render(c) }
  ];

  let activeTab = null;

  function init() {
    App.register('reports', { onShow });

    document.getElementById('reports-back-home').addEventListener('click', () => App.show('home', { replace: true }));
    document.getElementById('reports-print-settings').addEventListener('click', openSettings);
    document.getElementById('report-settings-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('report-settings-popup')));
    document.getElementById('report-settings-form').addEventListener('submit', saveSettings);

    const nav = document.getElementById('reports-nav');
    nav.innerHTML = tabs.map(t => `
      <button class="nav-icon-btn" data-key="${t.key}">
        <span class="nav-icon">${t.icon}</span>
        <span class="nav-label">${t.label}</span>
      </button>`).join('');

    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      selectTab(btn.dataset.key);
    });
  }

  function onShow() {
    selectTab(activeTab || 'statement');
  }

  function selectTab(key) {
    activeTab = key;
    document.querySelectorAll('#reports-nav .nav-icon-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.key === key);
    });
    const tab = tabs.find(t => t.key === key);
    const content = document.getElementById('reports-content');
    content.innerHTML = '';
    tab.render(content);
  }

  async function openSettings() {
    const settings = (await FarisDB.get(STORES.SETTINGS, SETTINGS_ID)) || {};
    document.getElementById('rs-show-header').checked = settings.reportShowHeader !== false;
    document.getElementById('rs-paper-size').value = settings.reportPaperSize || 'A4';
    document.getElementById('rs-orientation').value = settings.reportOrientation || 'portrait';
    document.getElementById('rs-margin-right').value = settings.reportMarginRight ?? 14;
    document.getElementById('rs-margin-left').value = settings.reportMarginLeft ?? 14;
    document.getElementById('rs-margin-top').value = settings.reportMarginTop ?? 14;
    document.getElementById('rs-margin-bottom').value = settings.reportMarginBottom ?? 14;
    document.getElementById('rs-color-mode').value = settings.reportColorMode || 'ملون';
    Utils.openSheet(document.getElementById('report-settings-popup'));
  }

  async function saveSettings(e) {
    e.preventDefault();
    const settings = (await FarisDB.get(STORES.SETTINGS, SETTINGS_ID)) || { id: SETTINGS_ID };
    settings.reportShowHeader = document.getElementById('rs-show-header').checked;
    settings.reportPaperSize = document.getElementById('rs-paper-size').value;
    settings.reportOrientation = document.getElementById('rs-orientation').value;
    settings.reportMarginRight = Number(document.getElementById('rs-margin-right').value) || 0;
    settings.reportMarginLeft = Number(document.getElementById('rs-margin-left').value) || 0;
    settings.reportMarginTop = Number(document.getElementById('rs-margin-top').value) || 0;
    settings.reportMarginBottom = Number(document.getElementById('rs-margin-bottom').value) || 0;
    settings.reportColorMode = document.getElementById('rs-color-mode').value;
    await FarisDB.put(STORES.SETTINGS, settings);
    Utils.closeSheet(document.getElementById('report-settings-popup'));
    Utils.toast('تم حفظ إعدادات الطباعة', 'success');
  }

  // تُستخدم من كل شاشات التقارير لجلب إعدادات الطباعة الحالية
  async function getPrintSettings() {
    return (await FarisDB.get(STORES.SETTINGS, SETTINGS_ID)) || {};
  }

  return { init, getPrintSettings };
})();
