/* =========================================================
   فاتورة المشتريات
   نفس بنية وأزرار شاشة فواتير المبيعات (مورد بدل عميل)، مع:
   - تبويب "مصاريف" لتحميل مصاريف الشراء على المخزون بأي حساب يُختار مباشرة
   - زر "توزيع المصاريف" (تحويل الكميات لأصغر وحدة، توزيع نسبي، إرجاعها)
   - قيد تلقائي مزدوج: (مدين مخزون / دائن مورد أو صندوق) و(مدين مخزون / دائن حسابات المصاريف)
   جميع تكاليف الأصناف (الإجمالي الأولي/توزيع المصاريف/الخصم/الإجمالي) بعملة المخزون المختار،
   بينما سعر الوحدة المُدخل يبقى بعملة الفاتورة كما أدخله المستخدم.
   ========================================================= */

const PurchaseInvoices = (function () {
  let mode = 'add'; // add | search
  let activeTab = 'items'; // items | expenses
  let draftLines = [];
  let draftExpenses = [];
  let lineCounter = 0;
  let expenseCounter = 0;
  let editId = null;
  let currentJournalId = null;
  let selectedInvoiceId = null;

  let suppliersCache = [];
  let warehousesCache = [];
  let cashboxesCache = [];
  let currenciesCache = [];
  let itemsCache = [];
  let unitsFlat = [];
  let mainGroupsCache = [];

  function currencyById(id) { return currenciesCache.find(c => c.id === id); }
  function unitById(id) { return unitsFlat.find(u => u.id === id); }
  function localCurrency() { return currenciesCache.find(c => c.type === 'محلي'); }
  function convertAmount(amount, fromCurrency, toCurrency) {
    if (!fromCurrency || !toCurrency || fromCurrency.id === toCurrency.id) return amount;
    const local = fromCurrency.type === 'محلي' ? amount : amount * fromCurrency.rate;
    return toCurrency.type === 'محلي' ? local : local / toCurrency.rate;
  }
  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

  async function render(container) {
    mode = 'add';
    activeTab = 'items';
    draftLines = [];
    draftExpenses = [];
    editId = null;
    selectedInvoiceId = null;

    suppliersCache = await FarisDB.getAll(STORES.SUPPLIERS);
    warehousesCache = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    cashboxesCache = await FarisDB.getAll(STORES.CASHBOXES);
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    itemsCache = await FarisDB.getAll(STORES.INV_ITEMS);
    unitsFlat = await FarisDB.getAll(STORES.INV_UNITS);
    mainGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);

    container.innerHTML = `
      <div class="toolbar icon-only" id="pi-toolbar">
        <button class="btn btn-icon" id="pi-dup" title="نسخ من فاتورة محددة" disabled>🔁</button>
        <button class="btn btn-icon" id="pi-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="pi-save" title="حفظ">💾</button>
        <button class="btn btn-icon" id="pi-search" title="بحث">🔍</button>
        <button class="btn btn-icon" id="pi-edit" title="تعديل" disabled>✏️</button>
        <button class="btn btn-icon" id="pi-print" title="طباعة" disabled>🖨️</button>
        <button class="btn btn-icon" id="pi-journal" title="عرض القيود" disabled>📋</button>
        <button class="btn btn-icon" id="pi-del" title="حذف" disabled>🗑️</button>
        <button class="btn btn-icon" id="pi-undo" title="تراجع من الإضافة">↩️</button>
      </div>

      <div id="pi-add-view"></div>
      <div id="pi-search-view" class="hidden"></div>

      <div class="popup-sheet" id="pi-journal-popup">
        <div class="popup-header"><span>القيود المحاسبية التلقائية للفاتورة</span><button class="btn-close" id="pi-journal-close">✖️</button></div>
        <div id="pi-journal-content"></div>
      </div>
    `;

    renderAddView();
    bindToolbar(container);
    setToolbarState('add-empty');
    document.getElementById('pi-no').value = await nextInvoiceNo();
  }

  function bindToolbar(container) {
    container.querySelector('#pi-add').addEventListener('click', onAddNew);
    container.querySelector('#pi-save').addEventListener('click', onSaveInvoice);
    container.querySelector('#pi-search').addEventListener('click', onToggleSearch);
    container.querySelector('#pi-edit').addEventListener('click', onEditSelected);
    container.querySelector('#pi-print').addEventListener('click', onPrintSelected);
    container.querySelector('#pi-journal').addEventListener('click', onViewJournal);
    container.querySelector('#pi-journal-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('pi-journal-popup')));
    container.querySelector('#pi-del').addEventListener('click', onDelete);
    container.querySelector('#pi-dup').addEventListener('click', onDuplicateFromSelected);
    container.querySelector('#pi-undo').addEventListener('click', onUndo);
  }

  function setToolbarState(state) {
    const dis = (id, v) => { const el = document.getElementById(id); if (el) el.disabled = v; };
    // Keep toolbar buttons visible in every state; do not hide them during new-entry mode.
    if (state === 'add-empty') { dis('pi-dup', true); dis('pi-edit', true); dis('pi-print', true); dis('pi-journal', true); dis('pi-del', true); }
    else if (state === 'add-saved') { dis('pi-dup', false); dis('pi-edit', false); dis('pi-print', false); dis('pi-journal', false); dis('pi-del', false); }
    else if (state === 'search-none') { dis('pi-dup', true); dis('pi-edit', true); dis('pi-print', true); dis('pi-journal', true); dis('pi-del', true); }
    else if (state === 'search-selected') { dis('pi-dup', false); dis('pi-edit', false); dis('pi-print', false); dis('pi-journal', false); dis('pi-del', false); }
  }

  /* -------------------- شاشة الإضافة -------------------- */
  function renderAddView() {
    const el = document.getElementById('pi-add-view');
    el.classList.remove('hidden');
    document.getElementById('pi-search-view').classList.add('hidden');

    el.innerHTML = `
      <div class="form-row cols-2">
        <label class="optional"><input type="text" id="pi-no" placeholder="رقم الفاتورة" readonly></label>
        <label class="required"><input type="date" id="pi-date" aria-label="التاريخ" required></label>
      </div>

      <div class="form-row cols-2">
        <label class="required">
          <select id="pi-type"><option value="" disabled selected hidden>نوع الفاتورة</option><option value="نقدي">نقدي</option><option value="آجل">آجل</option></select>
        </label>
        <label class="optional"><select id="pi-party-currency"><option value="" disabled selected hidden>رمز العملة</option></select></label>
      </div>

      <div class="form-row cols-2" id="pi-row-party">
        <label class="required hidden" id="pi-cashbox-no-wrap"><input type="text" id="pi-cashbox-no" placeholder="رقم الصندوق" readonly></label>
        <label class="required hidden" id="pi-cashbox-wrap">
          <div class="combo-wrap">
            <input type="text" id="pi-cashbox-input" autocomplete="off" placeholder="اسم الصندوق">
            <div class="autocomplete-list" id="pi-cashbox-list"></div>
          </div>
          <input type="hidden" id="pi-cashbox-id">
        </label>

        <label class="required hidden" id="pi-supplier-no-wrap"><input type="text" id="pi-supplier-no" placeholder="رقم المورد" readonly></label>
        <label class="required hidden" id="pi-supplier-wrap">
          <div class="combo-wrap">
            <input type="text" id="pi-supplier-input" autocomplete="off" placeholder="اسم المورد">
            <div class="autocomplete-list" id="pi-supplier-list"></div>
          </div>
          <input type="hidden" id="pi-supplier-id">
        </label>
      </div>

      <div class="form-row cols-2">
        <label class="optional"><input type="text" id="pi-exchange-rate" placeholder="سعر الصرف" readonly></label>
        <label class="optional"><input type="text" id="pi-local-amount" placeholder="المبلغ محلي" readonly></label>
      </div>

      <div class="form-row cols-2">
        <label class="optional"><input type="text" id="pi-reference" placeholder="رقم المرجع"></label>
        <label class="optional"><input type="text" id="pi-supplier-mobile" placeholder="رقم الجوال" readonly></label>
      </div>

      <div class="form-row cols-2">
        <label class="required"><select id="pi-warehouse" required><option value="" disabled selected hidden>المخزن</option></select></label>
        <label class="optional"><input type="text" id="pi-warehouse-rate" placeholder="سعر صرف عملة المخزون" readonly></label>
      </div>
      <input type="hidden" id="pi-warehouse-currency">
      <input type="hidden" id="pi-currency">

      <div class="toolbar" id="pi-tabs">
        <button type="button" class="btn btn-primary" id="pi-tab-items">الأصناف</button>
        <button type="button" class="btn btn-ghost" id="pi-tab-expenses">مصاريف</button>
      </div>

      <div id="pi-items-panel">
        <div class="table-scroll" id="pi-items-scroll">
          <table class="data-table" id="pi-items-table">
            <thead><tr>
              <th></th><th>رقم الصنف</th><th>اسم الصنف</th><th>الوحدة</th><th>رقم المخزن</th><th>الكمية</th><th>السعر الوحدة</th>
              <th>إجمالي التكلفة الأولية (بعملة المخزون)</th><th>توزيع المصاريف (بعملة المخزون)</th><th>مبلغ الخصم</th><th>الإجمالي التكلفة (بعملة المخزون)</th>
            </tr></thead>
            <tbody id="pi-lines-rows"></tbody>
          </table>
        </div>
      </div>

      <div class="popup-sheet" id="pi-line-menu-popup">
        <div class="popup-header"><span id="pi-line-menu-title">خيارات الصنف</span><button class="btn-close" id="pi-line-menu-close">✖️</button></div>
        <div class="sheet-actions" style="flex-direction:column; gap:8px;">
          <button type="button" class="btn btn-ghost full" id="pi-line-menu-movement">📋 بطاقة حركة الصنف</button>
          <button type="button" class="btn btn-ghost full" id="pi-line-menu-newitem">➕ إضافة صنف جديد</button>
          <button type="button" class="btn btn-danger full" id="pi-line-menu-delete">🗑️ حذف الصف</button>
        </div>
      </div>

      <div class="popup-sheet" id="pi-newitem-popup">
        <div class="popup-header"><span>إضافة صنف جديد</span><button class="btn-close" id="pi-newitem-close">✖️</button></div>
        <div class="form-grid">
          <label class="required"><input type="text" id="pi-ni-code" placeholder="رقم الصنف"></label>
          <label class="required"><input type="text" id="pi-ni-name" placeholder="اسم الصنف"></label>
          <label class="required"><select id="pi-ni-main-group"><option value="" disabled selected hidden>المجموعة الرئيسية</option></select></label>
          <label class="required"><select id="pi-ni-unit"><option value="" disabled selected hidden>الوحدة الأساسية</option></select></label>
        </div>
        <button type="button" class="btn btn-primary full" id="pi-ni-save">💾 حفظ وإضافة للفاتورة</button>
      </div>

      <div class="popup-sheet" id="pi-movement-popup">
        <div class="popup-header"><span>حركة الصنف</span><button class="btn-close" id="pi-movement-close">✖️</button></div>
        <div id="pi-movement-content"></div>
      </div>

      <div id="pi-expenses-panel" class="hidden">
        <div class="table-scroll" style="overflow-x:auto;">
          <table class="data-table" style="table-layout:auto; width:auto; min-width:100%;">
            <thead><tr>
              <th>رقم الحساب</th><th>رقم الحساب التحليلي</th><th>اسم الحساب</th><th>رمز العملة</th><th>دائن محلي</th><th>دائن أجنبي</th><th>البيان</th><th></th>
            </tr></thead>
            <tbody id="pi-expense-rows"></tbody>
          </table>
        </div>
        <div class="toolbar">
          <button type="button" class="btn btn-ghost" id="pi-add-expense">➕ إضافة مصروف</button>
          <button type="button" class="btn btn-primary" id="pi-distribute">🔀 توزيع المصاريف</button>
        </div>
        <p class="hint">يقوم النظام بتحويل كميات الأصناف إلى أصغر وحدة قياس، ثم يوزع إجمالي المصاريف (بالعملة المحلية) عليها نسبيًا حسب الكمية، ثم يعيد إسناد كل حصة إلى سطرها.</p>
      </div>

      <div class="form-grid" style="margin-top:10px;">
        <label class="optional">خصم الفاتورة (مبلغ محلي)<input type="number" step="0.01" id="pi-discount" value="0"></label>
      </div>

      <table class="data-table" style="margin-top:8px;">
        <tbody>
          <tr><td><b>إجمالي الكمية</b></td><td id="pi-total-qty">0</td>
              <td><b>إجمالي التكلفة الأولية (بعملة المخزون)</b></td><td id="pi-total-initial">0.00</td></tr>
          <tr><td><b>إجمالي المصاريف الموزعة (بعملة المخزون)</b></td><td id="pi-total-expenses">0.00</td>
              <td><b>إجمالي الخصم</b></td><td id="pi-total-discount">0.00</td></tr>
          <tr><td colspan="3"><b>الصافي النهائي (بعملة المخزون)</b></td><td id="pi-total-net"><b>0.00</b></td></tr>
        </tbody>
      </table>
    `;

    document.getElementById('pi-warehouse').innerHTML = '<option value="" disabled selected hidden>المخزن</option>' + warehousesCache.map(w => `<option value="${w.id}">${Utils.escapeHtml(w.name)}</option>`).join('');
    document.getElementById('pi-party-currency').innerHTML = '<option value="" disabled selected hidden>رمز العملة</option>' + currenciesCache.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('');
    document.getElementById('pi-date').value = new Date().toISOString().slice(0, 10);

    bindAddViewEvents();
    for (let i = 0; i < 10; i++) addInvoiceRow();
    switchTab('items');
    setHeaderEditable(false);
  }

  function setHeaderEditable(enabled) {
    ['pi-date', 'pi-type', 'pi-party-currency', 'pi-cashbox-input', 'pi-supplier-input', 'pi-reference', 'pi-warehouse'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.disabled = !enabled;
    });
  }

  function switchTab(key) {
    activeTab = key;
    document.getElementById('pi-tab-items').classList.toggle('btn-primary', key === 'items');
    document.getElementById('pi-tab-items').classList.toggle('btn-ghost', key !== 'items');
    document.getElementById('pi-tab-expenses').classList.toggle('btn-primary', key === 'expenses');
    document.getElementById('pi-tab-expenses').classList.toggle('btn-ghost', key !== 'expenses');
    document.getElementById('pi-items-panel').classList.toggle('hidden', key !== 'items');
    document.getElementById('pi-expenses-panel').classList.toggle('hidden', key !== 'expenses');
  }

  function bindAddViewEvents() {
    document.getElementById('pi-type').addEventListener('change', onTypeChange);
    document.getElementById('pi-tab-items').addEventListener('click', () => switchTab('items'));
    document.getElementById('pi-tab-expenses').addEventListener('click', () => switchTab('expenses'));

    document.getElementById('pi-party-currency').addEventListener('change', () => {
      document.getElementById('pi-currency').value = document.getElementById('pi-party-currency').value;
      updateExchangeAndLocalAmount();
    });

    document.getElementById('pi-warehouse').addEventListener('change', () => {
      updateWarehouseCurrencyDisplay();
      updateWarehousePreview();
    });

    const supplierInput = document.getElementById('pi-supplier-input');
    const supplierList = document.getElementById('pi-supplier-list');
    Utils.attachAutocomplete(supplierInput, supplierList, (query) => {
      const list = suppliersCache.map(s => ({ value: s.id, label: `${s.partyNumber} - ${s.name}`, displayValue: s.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      supplierInput.value = item.displayValue;
      document.getElementById('pi-supplier-id').value = item.value;
      const supplier = suppliersCache.find(s => s.id === item.value);
      document.getElementById('pi-supplier-no').value = supplier ? supplier.partyNumber : '';
      document.getElementById('pi-supplier-mobile').value = supplier ? (supplier.mobile || '') : '';
      applyPartyCurrency(supplier);
    });

    const cashboxInput = document.getElementById('pi-cashbox-input');
    const cashboxList = document.getElementById('pi-cashbox-list');
    Utils.attachAutocomplete(cashboxInput, cashboxList, (query) => {
      const list = cashboxesCache.map(c => ({ value: c.id, label: `${c.partyNumber} - ${c.name}`, displayValue: c.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      cashboxInput.value = item.displayValue;
      document.getElementById('pi-cashbox-id').value = item.value;
      const cashbox = cashboxesCache.find(c => c.id === item.value);
      document.getElementById('pi-cashbox-no').value = cashbox ? cashbox.partyNumber : '';
      applyPartyCurrency(cashbox);
    });

    document.getElementById('pi-add-expense').addEventListener('click', () => addExpenseRow());
    document.getElementById('pi-distribute').addEventListener('click', onDistributeExpenses);
    document.getElementById('pi-discount').addEventListener('input', recomputeTotals);

    document.getElementById('pi-line-menu-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('pi-line-menu-popup')));
    document.getElementById('pi-line-menu-movement').addEventListener('click', onLineMenuMovement);
    document.getElementById('pi-line-menu-newitem').addEventListener('click', onLineMenuNewItem);
    document.getElementById('pi-line-menu-delete').addEventListener('click', onLineMenuDelete);
    document.getElementById('pi-newitem-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('pi-newitem-popup')));
    document.getElementById('pi-ni-save').addEventListener('click', onSaveNewItem);
    document.getElementById('pi-movement-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('pi-movement-popup')));

    onTypeChange();
    updateExchangeAndLocalAmount();
    updateWarehouseCurrencyDisplay();
  }

  function applyPartyCurrency(party) {
    const currencyId = party && party.defaultCurrency ? party.defaultCurrency : null;
    document.getElementById('pi-currency').value = currencyId || '';
    document.getElementById('pi-party-currency').value = currencyId || '';
    updateExchangeAndLocalAmount();
  }

  function onTypeChange() {
    const type = document.getElementById('pi-type').value;
    const isCash = type === 'نقدي';
    const isCredit = type === 'آجل';
    document.getElementById('pi-cashbox-wrap').classList.toggle('hidden', !isCash);
    document.getElementById('pi-cashbox-no-wrap').classList.toggle('hidden', !isCash);
    document.getElementById('pi-supplier-wrap').classList.toggle('hidden', !isCredit);
    document.getElementById('pi-supplier-no-wrap').classList.toggle('hidden', !isCredit);
  }

  function updateWarehouseCurrencyDisplay() {
    const warehouse = warehousesCache.find(w => w.id === Number(document.getElementById('pi-warehouse').value));
    const currency = warehouse ? currencyById(warehouse.currencyId) : null;
    document.getElementById('pi-warehouse-currency').value = currency ? currency.id : '';
    document.getElementById('pi-warehouse-rate').value = currency ? (currency.type === 'محلي' ? '1' : currency.rate) : '';
  }

  function updateWarehousePreview() {
    const warehouse = warehousesCache.find(w => w.id === Number(document.getElementById('pi-warehouse').value));
    document.querySelectorAll('#pi-lines-rows .pi-wh-cell').forEach(td => { td.textContent = warehouse ? (warehouse.code || warehouse.name) : ''; });
  }

  function updateExchangeAndLocalAmount() {
    const invoiceCurrency = currencyById(Number(document.getElementById('pi-currency').value));
    const local = localCurrency();
    const warehouse = warehousesCache.find(w => w.id === Number(document.getElementById('pi-warehouse').value));
    const warehouseCurrency = warehouse ? currencyById(warehouse.currencyId) : null;
    const rateField = document.getElementById('pi-exchange-rate');
    const amountField = document.getElementById('pi-local-amount');
    if (!invoiceCurrency || !local) { rateField.value = ''; amountField.value = ''; return; }
    rateField.value = invoiceCurrency.type === 'محلي' ? '1' : invoiceCurrency.rate;
    // الصافي في جدول الإجماليات مُحتسَب بعملة المخزون؛ نحوّله للعملة المحلية هنا للعرض فقط
    const net = Number((document.getElementById('pi-total-net').textContent || '0').replace(/[^\d.-]/g, '')) || 0;
    amountField.value = warehouseCurrency ? convertAmount(net, warehouseCurrency, local).toFixed(2) : net.toFixed(2);
  }

  /* -------------------- بند الصنف -------------------- */
  function addInvoiceRow(prefill) {
    const row = {
      _id: ++lineCounter, itemCode: '', itemName: '', unitId: null, unitName: '',
      baseQty: 0, warehouseId: null, warehouseCode: '',
      qty: '', price: '', initialCostLocal: 0, expenseShareLocal: 0, lineDiscount: 0, totalCostLocal: 0
    };
    if (prefill) Object.assign(row, prefill);
    draftLines.push(row);
    const tbody = document.getElementById('pi-lines-rows');
    if (tbody) tbody.appendChild(buildRowEl(row));
    return row;
  }

  // يضمن دائمًا وجود صفوف فارغة كافية أسفل آخر صف مكتمل (دفعات من 5 صفوف - "صفوف لا نهائية")
  function ensureTrailingRows() {
    const emptyTrailing = [];
    for (let i = draftLines.length - 1; i >= 0 && !draftLines[i].itemCode; i--) emptyTrailing.unshift(draftLines[i]);
    if (emptyTrailing.length < 1) {
      for (let i = 0; i < 5; i++) addInvoiceRow();
    }
  }

  function focusNextRowFirstField(afterRid) {
    const idx = draftLines.findIndex(l => l._id === afterRid);
    if (idx === draftLines.length - 1) {
      for (let i = 0; i < 5; i++) addInvoiceRow();
    }
    const nextRow = draftLines[idx + 1];
    if (!nextRow) return;
    const tr = document.querySelector(`#pi-lines-rows tr[data-rid="${nextRow._id}"]`);
    if (tr) tr.querySelector('.pi-item-input').focus();
  }

  function buildRowEl(row) {
    const item = row.itemCode ? itemsCache.find(i => i.code === row.itemCode) : null;
    const unitOptions = (item ? item.units : []).map(u => {
      const unit = unitById(u.unitId);
      return `<option value="${u.unitId}" data-factor="${u.linkFactor || 1}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');
    const warehouse = warehousesCache.find(w => w.id === Number(document.getElementById('pi-warehouse').value));

    const tr = Utils.el(`
      <tr data-rid="${row._id}">
        <td><button type="button" class="btn-close" data-menu="${row._id}">⋮</button></td>
        <td>
          <div class="combo-wrap combo-compact">
            <input type="text" class="table-input pi-item-input" autocomplete="off" value="${row.itemCode ? Utils.escapeHtml(row.itemCode + ' - ' + row.itemName) : ''}">
            <div class="autocomplete-list pi-item-list"></div>
          </div>
        </td>
        <td class="pi-name-preview">${Utils.escapeHtml(row.itemName || '')}</td>
        <td><select class="table-input pi-item-unit">${unitOptions}</select></td>
        <td class="pi-wh-cell">${Utils.escapeHtml(row.warehouseCode || (warehouse ? (warehouse.code || warehouse.name) : ''))}</td>
        <td><input type="number" step="0.01" class="table-input pi-item-qty" value="${row.qty}"></td>
        <td><input type="number" step="0.01" class="table-input pi-item-price" value="${row.price}"></td>
        <td class="pi-initial-preview">${(row.initialCostLocal || 0).toFixed(2)}</td>
        <td class="pi-expense-preview">${(row.expenseShareLocal || 0).toFixed(2)}</td>
        <td><input type="number" step="0.01" class="table-input pi-item-discount" value="${row.lineDiscount || 0}"></td>
        <td class="pi-total-preview">${(row.totalCostLocal || 0).toFixed(2)}</td>
      </tr>
    `);

    if (row.unitId) tr.querySelector('.pi-item-unit').value = row.unitId;

    const itemInput = tr.querySelector('.pi-item-input');
    const itemList = tr.querySelector('.pi-item-list');
    Utils.attachAutocomplete(itemInput, itemList, (query) => {
      const list = itemsCache.map(it => ({ value: it.code, label: `${it.code} - ${it.name}`, displayValue: `${it.code} - ${it.name}` }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (picked) => {
      itemInput.value = picked.displayValue;
      onRowItemChosen(row._id, picked.value);
    });

    tr.querySelector('.pi-item-unit').addEventListener('change', () => onRowFieldInput(row._id));
    tr.querySelector('.pi-item-qty').addEventListener('input', () => onRowFieldInput(row._id));
    tr.querySelector('.pi-item-price').addEventListener('input', () => onRowFieldInput(row._id));
    tr.querySelector('.pi-item-discount').addEventListener('input', () => onRowFieldInput(row._id));
    tr.querySelector('[data-menu]').addEventListener('click', () => openLineMenu(row._id));

    // التنقل بالكيبورد: Enter ينتقل للحقل التالي بنفس الصف، وعند آخر حقل ينتقل لأول حقل بالصف التالي
    const order = ['.pi-item-input', '.pi-item-unit', '.pi-item-qty', '.pi-item-price', '.pi-item-discount'];
    order.forEach((sel, idx) => {
      tr.querySelector(sel).addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        if (idx === 0) {
          const currentRow = draftLines.find(l => l._id === row._id);
          const entered = tr.querySelector('pi-item-input').value.trim();
          const validItem = currentRow && currentRow.itemCode && itemsCache.some(it => it.code === currentRow.itemCode) && (entered === currentRow.itemCode || entered === `${currentRow.itemCode} - ${currentRow.itemName}`);
          if (!entered || !validItem) {
            Utils.toast(!entered ? 'يرجى إدخال رقم الصنف واختياره من القائمة' : 'رقم الصنف غير صحيح، اختر صنفًا من القائمة', 'error');
            tr.querySelector('pi-item-input').focus();
            return;
          }
        }
        if (idx < order.length - 1) tr.querySelector(order[idx + 1]).focus();
        else focusNextRowFirstField(row._id);
      });
    });

    return tr;
  }

  function onRowItemChosen(rid, code) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const item = itemsCache.find(i => i.code === code);
    row.itemCode = code;
    row.itemName = item ? item.name : '';
    row.unitId = item && item.units.length ? (item.units.find(u => u.isBase) || item.units[0]).unitId : null;

    const tr = document.querySelector(`#pi-lines-rows tr[data-rid="${rid}"]`);
    tr.querySelector('.pi-name-preview').textContent = row.itemName;
    const unitSelect = tr.querySelector('.pi-item-unit');
    unitSelect.innerHTML = (item ? item.units : []).map(u => {
      const unit = unitById(u.unitId);
      return `<option value="${u.unitId}" data-factor="${u.linkFactor || 1}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');
    if (row.unitId) unitSelect.value = row.unitId;

    ensureTrailingRows();
    onRowFieldInput(rid);
  }

  function onRowFieldInput(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row || !row.itemCode) return;
    const tr = document.querySelector(`#pi-lines-rows tr[data-rid="${rid}"]`);
    const warehouseId = Number(document.getElementById('pi-warehouse').value);
    const warehouse = warehousesCache.find(w => w.id === warehouseId);
    const unitSelect = tr.querySelector('.pi-item-unit');
    const linkFactor = Number((unitSelect.selectedOptions[0] || {}).dataset?.factor) || 1;

    row.unitId = Number(unitSelect.value) || null;
    row.unitName = unitById(row.unitId) ? unitById(row.unitId).name : '';
    row.warehouseId = warehouseId;
    row.warehouseCode = warehouse ? (warehouse.code || warehouse.name) : '';
    row.qty = tr.querySelector('.pi-item-qty').value;
    row.price = tr.querySelector('.pi-item-price').value;
    row.lineDiscount = Number(tr.querySelector('.pi-item-discount').value) || 0;

    const qty = Number(row.qty) || 0;
    const price = Number(row.price) || 0;
    row.baseQty = qty * linkFactor;

    const invoiceCurrency = currencyById(Number(document.getElementById('pi-currency').value));
    const warehouseCurrency = warehouse ? currencyById(warehouse.currencyId) : null;
    row.initialCostLocal = invoiceCurrency && warehouseCurrency ? convertAmount(qty * price, invoiceCurrency, warehouseCurrency) : (qty * price);
    row.totalCostLocal = Math.max(0, row.initialCostLocal - row.lineDiscount);

    tr.querySelector('.pi-initial-preview').textContent = row.initialCostLocal.toFixed(2);
    tr.querySelector('.pi-total-preview').textContent = row.totalCostLocal.toFixed(2);
    recomputeTotals();
  }

  /* -------------------- قائمة الخيارات السريعة (⋮) لكل صف -------------------- */
  let activeMenuLineId = null;

  function openLineMenu(lineId) {
    activeMenuLineId = lineId;
    const line = draftLines.find(l => l._id === lineId);
    document.getElementById('pi-line-menu-title').textContent = line && line.itemName ? `صنف: ${line.itemName}` : 'خيارات الصنف';
    Utils.openSheet(document.getElementById('pi-line-menu-popup'));
  }

  async function onLineMenuMovement() {
    const line = draftLines.find(l => l._id === activeMenuLineId);
    Utils.closeSheet(document.getElementById('pi-line-menu-popup'));
    if (!line || !line.itemCode) { Utils.toast('اختر صنفًا في هذا الصف أولًا', 'error'); return; }
    await openItemMovement(line.itemCode, line.itemName);
  }

  function onLineMenuNewItem() {
    Utils.closeSheet(document.getElementById('pi-line-menu-popup'));
    openNewItemPopup();
  }

  function onLineMenuDelete() {
    const tr = document.querySelector(`#pi-lines-rows tr[data-rid="${activeMenuLineId}"]`);
    if (tr) tr.remove();
    draftLines = draftLines.filter(l => l._id !== activeMenuLineId);
    Utils.closeSheet(document.getElementById('pi-line-menu-popup'));
    if (!draftLines.length) addInvoiceRow();
    recomputeTotals();
  }

  /* -------------------- إضافة صنف جديد سريعًا -------------------- */
  function openNewItemPopup() {
    document.getElementById('pi-ni-code').value = '';
    document.getElementById('pi-ni-name').value = '';
    document.getElementById('pi-ni-main-group').innerHTML = '<option value="" disabled selected hidden>المجموعة الرئيسية</option>' +
      mainGroupsCache.map(m => `<option value="${m.id}">${Utils.escapeHtml(m.name)}</option>`).join('');
    document.getElementById('pi-ni-unit').innerHTML = '<option value="" disabled selected hidden>الوحدة الأساسية</option>' +
      unitsFlat.map(u => `<option value="${u.id}">${Utils.escapeHtml(u.name)}</option>`).join('');
    Utils.openSheet(document.getElementById('pi-newitem-popup'));
  }

  async function onSaveNewItem() {
    const code = document.getElementById('pi-ni-code').value.trim();
    const name = document.getElementById('pi-ni-name').value.trim();
    const mainGroupId = Number(document.getElementById('pi-ni-main-group').value) || null;
    const unitId = Number(document.getElementById('pi-ni-unit').value) || null;
    if (!code || !name || !mainGroupId || !unitId) { Utils.toast('أكمل كل الحقول', 'error'); return; }
    if (itemsCache.some(i => i.code === code)) { Utils.toast('رقم الصنف مستخدم مسبقًا', 'error'); return; }

    const value = { code, name, mainGroupId, subGroupId: null, detailGroupId: null, units: [{ unitId, package: 1, level: 'أصغر وحدة', linkFactor: 1, isBase: true, isSellUnit: true, isPurchaseUnit: true }] };
    await FarisDB.put(STORES.INV_ITEMS, value);
    itemsCache.push(value);
    Utils.toast('تمت إضافة الصنف، وأُدرج في الفاتورة', 'success');
    Utils.closeSheet(document.getElementById('pi-newitem-popup'));

    const tr = document.querySelector(`#pi-lines-rows tr[data-rid="${activeMenuLineId}"]`);
    if (tr) {
      tr.querySelector('.pi-item-input').value = `${code} - ${name}`;
      onRowItemChosen(activeMenuLineId, code);
    }
  }

  async function openItemMovement(itemCode, itemName) {
    const warehouseId = Number(document.getElementById('pi-warehouse').value);
    const opening = (await FarisDB.getAllByIndex(STORES.INV_OPENING_STOCK, 'itemCode', itemCode)).filter(s => s.warehouseId === warehouseId);
    const entries = [];
    opening.forEach(s => entries.push({ date: '', type: 'رصيد افتتاحي', incoming: s.quantity, outgoing: 0 }));

    const invoices = await FarisDB.getAll(STORES.SALES_INVOICES);
    invoices.forEach(inv => {
            (inv.lines || []).forEach(l => { if ((l.warehouseId || inv.warehouseId) !== warehouseId) return; if (l.itemCode === itemCode) entries.push({ date: inv.date, type: 'فاتورة مبيعات', incoming: 0, outgoing: l.qty }); });
    });

    const returns = await FarisDB.getAll(STORES.SALES_RETURNS);
    returns.forEach(ret => {
      (ret.lines || []).forEach(l => { if ((l.warehouseId || ret.warehouseId) !== warehouseId) return; if (l.itemCode === itemCode) entries.push({ date: ret.date, type: 'مرتجع مبيعات', incoming: l.qty, outgoing: 0 }); });
    });

    const purchases = await FarisDB.getAll(STORES.PURCHASE_INVOICES);
    purchases.forEach(pinv => {
      if (pinv.warehouseId !== warehouseId) return;
      if (pinv.id === editId) return;
      (pinv.lines || []).forEach(l => { if (l.itemCode === itemCode) entries.push({ date: pinv.date, type: 'فاتورة مشتريات', incoming: l.qty, outgoing: 0 }); });
    });

    entries.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let balance = 0;
    const rows = entries.map(e => {
      balance += e.incoming - e.outgoing;
      return `<tr><td>${Utils.escapeHtml(e.date)}</td><td>${Utils.escapeHtml(e.type)}</td><td>${e.incoming || ''}</td><td>${e.outgoing || ''}</td><td>${balance}</td></tr>`;
    }).join('') || '<tr><td colspan="5" class="empty-row">لا توجد حركة مسجَّلة لهذا الصنف في هذا المخزن</td></tr>';

    document.getElementById('pi-movement-content').innerHTML = `
      <p><b>الصنف:</b> ${Utils.escapeHtml(itemName)}</p>
      <table class="data-table"><thead><tr><th>تاريخ</th><th>نوع الحركة</th><th>وارد</th><th>صادر</th><th>الرصيد</th></tr></thead>
      <tbody>${rows}</tbody></table>
    `;
    Utils.openSheet(document.getElementById('pi-movement-popup'));
  }


  /* -------------------- تبويب المصاريف -------------------- */
  function addExpenseRow(data) {
    const tbody = document.getElementById('pi-expense-rows');
    const rid = ++expenseCounter;
    const prefix = `pi-exp-${rid}`;
    const tr = Utils.el(`
      <tr data-rid="${rid}">
        <td>${AccountAnalyticPicker.markupCompact(prefix)}</td>
        <td>${AccountAnalyticPicker.markupAnalyticCompact(prefix)}</td>
        <td class="pi-exp-name"></td>
        <td><select id="${prefix}-currency" class="table-input"></select></td>
        <td class="pi-exp-local">0.00</td>
        <td><input type="number" step="0.01" class="table-input pi-exp-foreign" value="0"></td>
        <td><input type="text" class="table-input pi-exp-statement" placeholder="البيان"></td>
        <td><button type="button" class="btn-close" data-remove-exp="${rid}">✖️</button></td>
      </tr>
    `);
    tbody.appendChild(tr);

    const refresh = async () => {
      const value = await AccountAnalyticPicker.getValue(prefix);
      tr.querySelector('.pi-exp-name').textContent = value ? value.accountName : '';
      recomputeExpenseRowLocal(tr, prefix);
    };
    AccountAnalyticPicker.init(prefix, refresh);

    tr.querySelector(`#${prefix}-currency`).addEventListener('change', () => recomputeExpenseRowLocal(tr, prefix));
    tr.querySelector('.pi-exp-foreign').addEventListener('input', () => recomputeExpenseRowLocal(tr, prefix));
    tr.querySelector('[data-remove-exp]').addEventListener('click', () => { tr.remove(); recomputeTotals(); });

    if (data) {
      AccountAnalyticPicker.setValue(prefix, data).then(() => {
        tr.querySelector('.pi-exp-foreign').value = data.foreignAmount || 0;
        tr.querySelector('.pi-exp-statement').value = data.statement || '';
        recomputeExpenseRowLocal(tr, prefix);
      });
    }
  }

  function recomputeExpenseRowLocal(tr, prefix) {
    const currencyId = Number(document.getElementById(`${prefix}-currency`).value) || null;
    const currency = currencyId ? currencyById(currencyId) : null;
    const foreign = Number(tr.querySelector('.pi-exp-foreign').value) || 0;
    const local = currency ? convertAmount(foreign, currency, localCurrency()) : foreign;
    tr.querySelector('.pi-exp-local').textContent = local.toFixed(2);
    recomputeTotals();
  }

  async function collectExpenses() {
    const rows = Array.from(document.querySelectorAll('#pi-expense-rows tr[data-rid]'));
    const result = [];
    for (const tr of rows) {
      const rid = tr.dataset.rid;
      const prefix = `pi-exp-${rid}`;
      const value = await AccountAnalyticPicker.getValue(prefix);
      if (!value) continue;
      const foreignAmount = Number(tr.querySelector('.pi-exp-foreign').value) || 0;
      const localAmount = Number(tr.querySelector('.pi-exp-local').textContent) || 0;
      const statement = tr.querySelector('.pi-exp-statement').value.trim();
      result.push({ ...value, foreignAmount, localAmount, statement });
    }
    return result;
  }

  function totalExpensesLocal() {
    return Array.from(document.querySelectorAll('#pi-expense-rows .pi-exp-local')).reduce((s, td) => s + (Number(td.textContent) || 0), 0);
  }

  // توزيع المصاريف: تحويل كل الكميات لأصغر وحدة قياس (baseQty)، توزيع نسبي بعملة المخزون، ثم إسناد الحصة لكل سطر
  function onDistributeExpenses() {
    const filled = draftLines.filter(l => l.itemCode);
    if (!filled.length) { Utils.toast('أضف أصنافًا للفاتورة أولًا', 'error'); return; }
    const warehouse = warehousesCache.find(w => w.id === Number(document.getElementById('pi-warehouse').value));
    const warehouseCurrency = warehouse ? currencyById(warehouse.currencyId) : null;
    const local = localCurrency();
    if (!warehouseCurrency) { Utils.toast('اختر المخزن أولًا', 'error'); return; }
    const totalExpenses = convertAmount(totalExpensesLocal(), local, warehouseCurrency);
    const totalBaseQty = filled.reduce((s, l) => s + l.baseQty, 0);
    if (!totalBaseQty) { Utils.toast('تعذّر التوزيع، الكميات غير صحيحة', 'error'); return; }

    const perBaseUnit = totalExpenses / totalBaseQty;
    filled.forEach(l => {
      l.expenseShareLocal = round2(perBaseUnit * l.baseQty);
      l.totalCostLocal = Math.max(0, l.initialCostLocal + l.expenseShareLocal - l.lineDiscount);
      const tr = document.querySelector(`#pi-lines-rows tr[data-rid="${l._id}"]`);
      if (tr) {
        tr.querySelector('.pi-expense-preview').textContent = l.expenseShareLocal.toFixed(2);
        tr.querySelector('.pi-total-preview').textContent = l.totalCostLocal.toFixed(2);
      }
    });
    recomputeTotals();
    Utils.toast('تم توزيع المصاريف على الأصناف بنجاح', 'success');
  }

  /* -------------------- الإجماليات -------------------- */
  function recomputeTotals() {
    const filled = draftLines.filter(l => l.itemCode);
    const totalQty = filled.reduce((s, l) => s + (Number(l.qty) || 0), 0);
    const totalInitial = filled.reduce((s, l) => s + l.initialCostLocal, 0);
    const totalExpensesAllocated = filled.reduce((s, l) => s + l.expenseShareLocal, 0);
    const warehouse = warehousesCache.find(w => w.id === Number(document.getElementById('pi-warehouse').value));
    const warehouseCurrency = warehouse ? currencyById(warehouse.currencyId) : null;
    const headerDiscountLocal = Number(document.getElementById('pi-discount').value) || 0;
    const headerDiscount = warehouseCurrency ? convertAmount(headerDiscountLocal, localCurrency(), warehouseCurrency) : headerDiscountLocal;
    const lineDiscounts = filled.reduce((s, l) => s + l.lineDiscount, 0);
    const totalDiscount = lineDiscounts + headerDiscount;
    const net = Math.max(0, totalInitial + totalExpensesAllocated - totalDiscount);

    document.getElementById('pi-total-qty').textContent = totalQty;
    document.getElementById('pi-total-initial').textContent = totalInitial.toFixed(2);
    document.getElementById('pi-total-expenses').textContent = totalExpensesAllocated.toFixed(2);
    document.getElementById('pi-total-discount').textContent = totalDiscount.toFixed(2);
    document.getElementById('pi-total-net').innerHTML = `<b>${net.toFixed(2)}</b>`;
    updateExchangeAndLocalAmount();
  }

  async function nextInvoiceNo() {
    const settings = await PurchaseConfig.getSettings();
    const invoices = await FarisDB.getAll(STORES.PURCHASE_INVOICES);
    return `${settings.invoicePrefix}${invoices.length + 1}`;
  }

  async function onAddNew() {
    mode = 'add';
    editId = null;
    currentJournalId = null;
    draftLines = [];
    draftExpenses = [];
    renderAddView();
    setHeaderEditable(true);
    const localCur = localCurrency();
    if (localCur && !document.getElementById('pi-currency').value) {
      document.getElementById('pi-currency').value = localCur.id;
      document.getElementById('pi-party-currency').value = localCur.id;
    }
    updateExchangeAndLocalAmount();
    document.getElementById('pi-no').value = await nextInvoiceNo();
    setToolbarState('add-empty');
  }

  function onUndo() {
    draftLines = [];
    editId = null;
    currentJournalId = null;
    renderAddView();
    setToolbarState('add-empty');
  }

  /* -------------------- توليد القيود المحاسبية التلقائية -------------------- */
  async function buildJournalLines(invoice, expenses) {
    const warehouse = warehousesCache.find(w => w.id === invoice.warehouseId);
    if (!warehouse) return { error: 'تعذر تحديد المخزن' };
    const mapping = await FarisDB.get(STORES.INV_GL_MAPPING, warehouse.groupId);
    const allAccounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const resolveAccount = (acc) => {
      if (!acc) return acc;
      const found = allAccounts.find(a => a.code === acc.code);
      return found ? { code: acc.code, name: found.name } : acc;
    };
    if (!mapping || !mapping.inventoryAccount) {
      return { error: `تعذر إنشاء القيد، حساب المخزون غير مربوط في "ربط المخزون بالأستاذ العام" لمجموعة مخازن (${warehouse.name})` };
    }

    const invoiceCurrency = currencyById(invoice.currencyId);
    const warehouseCurrency = currencyById(warehouse.currencyId);
    const local = localCurrency();
    const invRate = invoiceCurrency.type === 'محلي' ? 1 : invoiceCurrency.rate;
    const whRate = warehouseCurrency.type === 'محلي' ? 1 : warehouseCurrency.rate;

    let creditAccount, creditAnalyticCode = '', creditAnalyticName = '';
    if (invoice.type === 'نقدي') {
      const cashbox = cashboxesCache.find(c => c.id === invoice.cashboxId);
      if (!cashbox) return { error: 'اختر صندوق الفاتورة لإنشاء القيد' };
      creditAccount = { code: cashbox.parentAccountCode, name: cashbox.name };
      creditAnalyticCode = `${cashbox.parentAccountCode}-${cashbox.partyNumber}`;
      creditAnalyticName = cashbox.name;
    } else {
      const supplier = suppliersCache.find(s => s.id === invoice.supplierId);
      if (!supplier) return { error: 'اختر مورد الفاتورة لإنشاء القيد' };
      creditAccount = { code: supplier.parentAccountCode, name: supplier.name };
      creditAnalyticCode = `${supplier.parentAccountCode}-${supplier.partyNumber}`;
      creditAnalyticName = supplier.name;
    }

    const mk = (account, analyticCode, analyticName, currency, rate, statement, debit, credit, entryGroup) => ({
      accountCode: account.code, accountName: account.name,
      analyticCode: analyticCode || account.code, analyticName: analyticName || account.name,
      currencyId: currency.id, currencySymbol: currency.symbol, exchangeRate: rate,
      statement, entryGroup,
      debit: round2(debit), credit: round2(credit),
      debitLocal: round2(convertAmount(debit, currency, local)),
      creditLocal: round2(convertAmount(credit, currency, local))
    });

    const lines = [];
    // ملاحظة: beforeDiscount و lineDiscountsTotal أصبحا محسوبين بعملة المخزون (وليس بالعملة المحلية)
    const itemsNetWarehouseCurrency = invoice.beforeDiscount - invoice.lineDiscountsTotal;
    const itemsNetInvoiceCurrency = convertAmount(itemsNetWarehouseCurrency, warehouseCurrency, invoiceCurrency);

    // القيد الأول: مدين المخزون (بعملة المخزون) / دائن المورد أو الصندوق (بعملة الفاتورة)
    const statement1 = invoice.type === 'نقدي'
      ? `فاتورة مشتريات نقدية رقم ${invoice.invoiceNo}`
      : `فاتورة مشتريات آجلة رقم ${invoice.invoiceNo} من المورد ${creditAnalyticName}`;
    lines.push(mk(resolveAccount(mapping.inventoryAccount), '', '', warehouseCurrency, whRate, statement1, itemsNetWarehouseCurrency, 0, 1));
    lines.push(mk(creditAccount, creditAnalyticCode, creditAnalyticName, invoiceCurrency, invRate, statement1, 0, itemsNetInvoiceCurrency, 1));

    // القيد الثاني: تحميل مصاريف المشتريات على المخزون (مدين مخزون / دائن كل حساب مصروف)
    const totalExpensesLocalAmt = expenses.reduce((s, e) => s + e.localAmount, 0);
    if (totalExpensesLocalAmt > 0) {
      lines.push(mk(resolveAccount(mapping.inventoryAccount), '', '', warehouseCurrency, whRate, `تحميل مصاريف مشتريات فاتورة رقم ${invoice.invoiceNo}`, convertAmount(totalExpensesLocalAmt, local, warehouseCurrency), 0, 2));
      expenses.forEach(e => {
        const currency = currencyById(e.currencyId);
        lines.push(mk({ code: e.accountCode, name: e.accountName }, e.analyticCode, e.analyticName, currency, currency.type === 'محلي' ? 1 : currency.rate, e.statement || `مصروف مشتريات فاتورة رقم ${invoice.invoiceNo}`, 0, e.foreignAmount, 2));
      });
    }

    return { lines };
  }

  async function onSaveInvoice() {
    const filledLines = draftLines.filter(l => l.itemCode);
    if (!filledLines.length) { Utils.toast('أضف صنفًا واحدًا على الأقل', 'error'); return; }
    const invalidLine = filledLines.find(l => !(Number(l.qty) > 0) || !(Number(l.price) > 0));
    if (invalidLine) { Utils.toast(`أكمل الكمية والسعر لصنف "${invalidLine.itemName}"`, 'error'); return; }
    const type = document.getElementById('pi-type').value;
    if (!type) { Utils.toast('اختر نوع الفاتورة', 'error'); return; }

    const warehouseId = Number(document.getElementById('pi-warehouse').value);
    if (!warehouseId) { Utils.toast('اختر المخزن', 'error'); return; }
    if (type === 'نقدي' && !document.getElementById('pi-cashbox-id').value) { Utils.toast('اختر الصندوق', 'error'); return; }
    if (type === 'آجل' && !document.getElementById('pi-supplier-id').value) { Utils.toast('اختر المورد', 'error'); return; }
    if (!document.getElementById('pi-currency').value) {
      Utils.toast('تعذّر تحديد عملة الفاتورة، تأكد أن للجهة المختارة عملة افتراضية في بياناتها', 'error');
      return;
    }

    const expenses = await collectExpenses();
    const warehouseForSave = warehousesCache.find(w => w.id === warehouseId);
    const warehouseCurrencyForSave = warehouseForSave ? currencyById(warehouseForSave.currencyId) : null;
    const beforeDiscount = filledLines.reduce((s, l) => s + l.initialCostLocal + l.expenseShareLocal, 0);
    const lineDiscountsTotal = filledLines.reduce((s, l) => s + l.lineDiscount, 0);
    const headerDiscountLocal = Number(document.getElementById('pi-discount').value) || 0;
    const headerDiscount = warehouseCurrencyForSave ? convertAmount(headerDiscountLocal, localCurrency(), warehouseCurrencyForSave) : headerDiscountLocal;
    const net = Math.max(0, beforeDiscount - lineDiscountsTotal - headerDiscount);

    const supplier = suppliersCache.find(s => s.id === Number(document.getElementById('pi-supplier-id').value));
    const cashbox = cashboxesCache.find(c => c.id === Number(document.getElementById('pi-cashbox-id').value));

    const invoice = {
      invoiceNo: document.getElementById('pi-no').value || await nextInvoiceNo(),
      date: document.getElementById('pi-date').value,
      type,
      supplierId: type === 'آجل' ? Number(document.getElementById('pi-supplier-id').value) : null,
      supplierName: supplier ? supplier.name : '',
      cashboxId: type === 'نقدي' ? Number(document.getElementById('pi-cashbox-id').value) : null,
      cashboxName: cashbox ? cashbox.name : '',
      reference: document.getElementById('pi-reference').value.trim(),
      warehouseId,
      currencyId: Number(document.getElementById('pi-currency').value),
      lines: filledLines.map(({ _id, ...rest }) => ({ ...rest, qty: Number(rest.qty), price: Number(rest.price) })),
      expenses,
      discount: headerDiscountLocal, lineDiscountsTotal, beforeDiscount, net
    };
    if (editId) invoice.id = editId;
    if (currentJournalId) invoice.journalId = currentJournalId;

    const journalResult = await buildJournalLines(invoice, expenses);
    if (journalResult.error) { Utils.toast(journalResult.error, 'error'); return; }
    invoice.journalLines = journalResult.lines;

    const savedId = await FarisDB.put(STORES.PURCHASE_INVOICES, invoice);

    const journalPayload = { date: invoice.date, lines: journalResult.lines.map(l => ({ ...l, refNo: invoice.invoiceNo })) };
    if (currentJournalId) {
      // تعديل فاتورة موجودة: نحدّث نفس القيد بدل إنشاء قيد جديد يسبب تكرارًا
      const existingEntry = await FarisDB.get(STORES.JOURNAL, currentJournalId);
      journalPayload.id = currentJournalId;
      journalPayload.entryNo = existingEntry ? existingEntry.entryNo : String(currentJournalId);
      await FarisDB.put(STORES.JOURNAL, journalPayload);
    } else {
      const journalEntries = await FarisDB.getAll(STORES.JOURNAL);
      const entryNo = journalEntries.length ? Math.max(...journalEntries.map(j => Number(j.entryNo) || 0)) + 1 : 1;
      journalPayload.entryNo = String(entryNo);
      currentJournalId = await FarisDB.put(STORES.JOURNAL, journalPayload);
      invoice.id = savedId;
      invoice.journalId = currentJournalId;
      await FarisDB.put(STORES.PURCHASE_INVOICES, invoice);
    }

    Utils.toast('تم حفظ فاتورة المشتريات وترحيل قيودها المحاسبية بنجاح', 'success');
    editId = savedId;
    setToolbarState('add-saved');
    setHeaderEditable(false);
  }

  /* -------------------- البحث / القائمة -------------------- */
  async function onToggleSearch() {
    mode = mode === 'search' ? 'add' : 'search';
    if (mode === 'search') {
      document.getElementById('pi-add-view').classList.add('hidden');
      const el = document.getElementById('pi-search-view');
      el.classList.remove('hidden');
      await renderSearchView(el);
    } else {
      document.getElementById('pi-search-view').classList.add('hidden');
      document.getElementById('pi-add-view').classList.remove('hidden');
      setToolbarState('add-empty');
    }
  }

  async function renderSearchView(el) {
    el.innerHTML = `
      <div class="toolbar search-row">
        <input type="text" id="pi-list-search" placeholder="🔍 بحث...">
      </div>
      <div class="table-scroll" style="overflow-x:auto;">
        <table class="data-table">
          <thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>المورد/الصندوق</th><th>المخزن</th><th>النوع</th><th>الصافي محلي</th></tr></thead>
          <tbody id="pi-list-rows"></tbody>
        </table>
      </div>
    `;
    el.querySelector('#pi-list-search').addEventListener('input', loadListRows);
    await loadListRows();
    setToolbarState('search-none');
  }

  async function loadListRows() {
    let invoices = await FarisDB.getAll(STORES.PURCHASE_INVOICES);
    const search = document.getElementById('pi-list-search').value.trim();
    const whMap = Object.fromEntries(warehousesCache.map(w => [w.id, w.name]));

    if (search) {
      invoices = invoices.filter(inv => {
        const haystack = [inv.invoiceNo, inv.date, inv.supplierName, inv.cashboxName, whMap[inv.warehouseId], inv.type].join(' ');
        return haystack.includes(search);
      });
    }

    const rows = document.getElementById('pi-list-rows');
    rows.innerHTML = invoices.map(inv => `
      <tr data-id="${inv.id}">
        <td>${Utils.escapeHtml(inv.invoiceNo)}</td><td>${Utils.escapeHtml(inv.date)}</td>
        <td>${Utils.escapeHtml(inv.supplierName || inv.cashboxName || '')}</td><td>${Utils.escapeHtml(whMap[inv.warehouseId] || '')}</td>
        <td>${Utils.escapeHtml(inv.type)}</td><td>${inv.net.toFixed(2)}</td>
      </tr>`).join('') || '<tr><td colspan="6" class="empty-row">لا توجد فواتير مشتريات محفوظة بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectInvoiceRow(Number(tr.dataset.id), tr));
    });
  }

  function selectInvoiceRow(id, tr) {
    selectedInvoiceId = id;
    document.querySelectorAll('#pi-list-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    setToolbarState('search-selected');
  }

  async function loadInvoiceIntoAddFields(id) {
    const inv = await FarisDB.get(STORES.PURCHASE_INVOICES, id);
    document.getElementById('pi-add-view').classList.remove('hidden');
    document.getElementById('pi-search-view').classList.add('hidden');
    renderAddView();

    document.getElementById('pi-no').value = inv.invoiceNo;
    document.getElementById('pi-date').value = inv.date;
    document.getElementById('pi-type').value = inv.type;
    onTypeChange();
    document.getElementById('pi-currency').value = inv.currencyId;
    document.getElementById('pi-party-currency').value = inv.currencyId;
    document.getElementById('pi-warehouse').value = inv.warehouseId;
    updateWarehouseCurrencyDisplay();
    document.getElementById('pi-reference').value = inv.reference || '';
    document.getElementById('pi-discount').value = inv.discount;

    if (inv.supplierId) {
      const supplier = suppliersCache.find(s => s.id === inv.supplierId);
      document.getElementById('pi-supplier-input').value = supplier ? supplier.name : inv.supplierName;
      document.getElementById('pi-supplier-id').value = inv.supplierId;
      document.getElementById('pi-supplier-no').value = supplier ? supplier.partyNumber : '';
      document.getElementById('pi-supplier-mobile').value = supplier ? (supplier.mobile || '') : '';
    }
    if (inv.cashboxId) {
      const cashbox = cashboxesCache.find(c => c.id === inv.cashboxId);
      document.getElementById('pi-cashbox-input').value = cashbox ? cashbox.name : inv.cashboxName;
      document.getElementById('pi-cashbox-id').value = inv.cashboxId;
      document.getElementById('pi-cashbox-no').value = cashbox ? cashbox.partyNumber : '';
    }

    draftLines = [];
    document.getElementById('pi-lines-rows').innerHTML = '';
    (inv.lines || []).forEach(l => addInvoiceRow(l));
    for (let i = 0; i < 5; i++) addInvoiceRow();

    (inv.expenses || []).forEach(e => addExpenseRow({ ...e }));

    recomputeTotals();
    updateWarehousePreview();
    editId = inv.id;
    currentJournalId = inv.journalId || null;
    setToolbarState('add-saved');
    mode = 'add';
    setHeaderEditable(true);
  }

  // يتحقق أن تعديل/حذف فاتورة الشراء آمن زمنيًا: لا حركة منصرفة لاحقة (بيع أو مرجوع شراء) اعتمدت على توفر هذه الكمية
  async function findLockingMovement(inv) {
    for (let idx = 0; idx < (inv.lines || []).length; idx++) {
      const l = inv.lines[idx];
      const key = `purchase-invoice-${inv.id}-${idx}`;
      const blocker = await ItemMovementEngine.findBlockingLaterMovement(l.itemCode, inv.warehouseId, inv.date, true, key);
      if (blocker) return { itemName: l.itemName, blocker };
    }
    return null;
  }

  async function onEditSelected() {
    if (!selectedInvoiceId) return;
    const inv = await FarisDB.get(STORES.PURCHASE_INVOICES, selectedInvoiceId);
    const locked = await findLockingMovement(inv);
    if (locked) {
      Utils.toast(`لا يمكن تعديل الفاتورة: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    await loadInvoiceIntoAddFields(selectedInvoiceId);
  }

  async function onDuplicateFromSelected() {
    const id = editId || selectedInvoiceId;
    if (!id) return;
    await loadInvoiceIntoAddFields(id);
    editId = null;
    currentJournalId = null;
    document.getElementById('pi-no').value = await nextInvoiceNo();
    document.getElementById('pi-date').value = new Date().toISOString().slice(0, 10);
    setToolbarState('add-empty');
    Utils.toast('انسخت بيانات الفاتورة، عدّل ما يلزم ثم احفظ كفاتورة جديدة', 'info');
  }

  async function onDelete() {
    const id = editId || selectedInvoiceId;
    if (!id) return;
    const inv = await FarisDB.get(STORES.PURCHASE_INVOICES, id);
    const locked = await findLockingMovement(inv);
    if (locked) {
      Utils.toast(`لا يمكن حذف الفاتورة: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    const ok = await Utils.confirmDialog('هل تريد حذف هذه الفاتورة؟ (لا يمكن التراجع)');
    if (!ok) return;
    if (inv && inv.journalId) {
      await FarisDB.remove(STORES.JOURNAL, inv.journalId);
    }
    await FarisDB.remove(STORES.PURCHASE_INVOICES, id);
    Utils.toast('تم حذف الفاتورة وقيدها المحاسبي', 'success');
    if (mode === 'search') await loadListRows();
    else onAddNew();
  }

  async function onViewJournal() {
    const id = editId || selectedInvoiceId;
    if (!id) return;
    const inv = await FarisDB.get(STORES.PURCHASE_INVOICES, id);
    const lines = inv.journalLines || [];
    const entry1 = lines.filter(l => l.entryGroup === 1);
    const entry2 = lines.filter(l => l.entryGroup === 2);

    const renderEntryTable = (entryLines, title) => {
      if (!entryLines.length) return '';
      const rows = entryLines.map(l => `
        <tr>
          <td>${Utils.escapeHtml(l.accountCode)}</td><td>${Utils.escapeHtml(l.accountName)}</td>
          <td>${Utils.escapeHtml(l.currencySymbol || '')}</td><td>${l.exchangeRate || ''}</td>
          <td>${Utils.escapeHtml(l.statement)}</td>
          <td>${l.debit || ''}</td><td>${l.credit || ''}</td><td>${l.debitLocal || ''}</td><td>${l.creditLocal || ''}</td>
        </tr>`).join('');
      return `
        <h4 style="margin:14px 0 6px;">${title}</h4>
        <div class="table-scroll" style="overflow-x:auto;">
          <table class="data-table" style="table-layout:auto; width:auto; min-width:100%;">
            <thead><tr><th>رقم الحساب</th><th>اسم الحساب</th><th>رمز العملة</th><th>سعر الصرف</th><th>البيان</th><th>مدين</th><th>دائن</th><th>مدين محلي</th><th>دائن محلي</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>`;
    };

    document.getElementById('pi-journal-content').innerHTML =
      renderEntryTable(entry1, 'القيد الأول (المخزون مقابل المورد/الصندوق)') +
      renderEntryTable(entry2, 'القيد الثاني (تحميل مصاريف المشتريات على المخزون)') ||
      '<p class="hint">لا توجد قيود محفوظة لهذه الفاتورة.</p>';

    Utils.openSheet(document.getElementById('pi-journal-popup'));
  }

  function onPrintSelected() {
    const id = editId || selectedInvoiceId;
    if (!id) return;
    FarisDB.get(STORES.PURCHASE_INVOICES, id).then(inv => {
      const warehouse = warehousesCache.find(w => w.id === inv.warehouseId);
      const currency = warehouse ? currencyById(warehouse.currencyId) : null;
      const symbol = currency ? currency.symbol : '';
      const currencyName = currency ? currency.name : '';
      const local = localCurrency();
      const headerDiscountInWhCurrency = currency && local ? convertAmount(inv.discount, local, currency) : (inv.discount || 0);
      const totalDiscount = (inv.lineDiscountsTotal || 0) + headerDiscountInWhCurrency;
      const partyName = inv.type === 'نقدي' ? inv.cashboxName : inv.supplierName;
      const partyLabel = inv.type === 'نقدي' ? 'اسم الصندوق' : 'اسم المورد';

      const headers = ['م', 'رقم الصنف', 'اسم الصنف', 'الوحدة', 'الكمية', 'السعر الوحدة', 'إجمالي أولي', 'مصاريف موزعة', 'خصم', 'الإجمالي'];
      const rows = inv.lines.map((l, i) => [i + 1, l.itemCode, l.itemName, l.unitName, l.qty, l.price.toFixed(2), l.initialCostLocal.toFixed(2), l.expenseShareLocal.toFixed(2), l.lineDiscount.toFixed(2), l.totalCostLocal.toFixed(2)]);

      const extraHeaderHtml = `
        <div class="doc-header-row">
          <div class="dh-right"><b>رقم الفاتورة:</b> ${Utils.escapeHtml(inv.invoiceNo)}</div>
          <div class="dh-center">فاتورة مشتريات: ${Utils.escapeHtml(inv.type)}</div>
          <div class="dh-left">${Utils.escapeHtml(inv.date)}</div>
        </div>
        <div class="doc-header-row">
          <div class="dh-right"><b>${Utils.escapeHtml(partyLabel)}:</b> ${Utils.escapeHtml(partyName || '')}</div>
          <div class="dh-center"></div>
          <div class="dh-left">${Utils.escapeHtml(currencyName)} (عملة المخزون)</div>
        </div>
      `;

      const discountLine = totalDiscount > 0
        ? `<div class="df-line"><b>الخصم:</b> <span>${totalDiscount.toFixed(2)}</span></div>`
        : '';
      const netWords = ReportPrint.amountToWords(inv.net, currencyName, currency ? currency.fraction : '');
      const extraFooterHtml = `
        <div class="doc-footer-lines">
          <div class="df-line"><b>اجمالي الفاتورة:</b> <span>${inv.beforeDiscount.toFixed(2)} ${Utils.escapeHtml(symbol)}</span></div>
          ${discountLine}
          <div class="df-line"><b>اجمالي صافي الفاتورة:</b> <span>${inv.net.toFixed(2)} ${Utils.escapeHtml(symbol)}</span></div>
          <div class="df-words"><b>صافي اجمالي الفاتورة:</b> ${Utils.escapeHtml(netWords)}</div>
        </div>
      `;

      ReportPrint.print({
        title: `فاتورة مشتريات رقم ${inv.invoiceNo}`,
        extraHeaderHtml, extraFooterHtml,
        headers, rows
      });
    });
  }

  return { render };
})();
