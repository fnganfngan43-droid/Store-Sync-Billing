# Tasks
- [x] Connect account statement advanced filters to actual report rows.
- [x] Show summary net balances in the correct debit/credit column, including printing.
- [x] Verify filter and balance calculations with focused tests and isolated browser/print checks.
- [x] Move sales setup to an icon-only gear at the left of the sales screen header.
